// 서버 없이 동작하도록 바꾼 부분: 제품 검색 필터, 문의 메모 저장.
(function () {
  var params = new URLSearchParams(location.search);

  // 제품 찾기: products.html?c=분류번호&q=검색어
  var cards = document.querySelector('.cards');
  var filterForm = document.querySelector('form.search select[name="c"]');
  if (cards && filterForm) {
    var c = params.get('c') || '';
    var q = (params.get('q') || '').trim();
    var select = document.querySelector('select[name="c"]');
    var input = document.querySelector('form.search input[name="q"]');
    if (select) select.value = c;
    if (input) input.value = q;
    var catName = select && c ? select.options[select.selectedIndex].text : '';
    var shown = 0;
    cards.querySelectorAll(':scope > a').forEach(function (a) {
      var cat = (a.querySelector('small') || {}).textContent || '';
      var name = (a.querySelector('h3') || {}).textContent || '';
      var ok = (!catName || cat === catName) && (name + cat).indexOf(q) !== -1;
      a.hidden = !ok;
      if (ok) shown++;
    });
    var count = Array.prototype.find.call(document.querySelectorAll('main p'), function (p) { return /개 품목$/.test(p.textContent); });
    if (count) count.textContent = shown + '개 품목';
    if (!shown) {
      var back = document.createElement('a');
      back.href = 'products.html';
      back.textContent = '전체 제품 다시 보기 →';
      cards.after(back);
    }
  }

  // 거래 문의: 외부 전송 없이 내 컴퓨터에 문의 메모로 저장
  var form = document.querySelector('form[method="post"]');
  if (form && form.querySelector('[name="message"]')) {
    var pid = params.get('pid');
    var product = form.querySelector('select[name="pid"]');
    if (pid && product) product.value = pid;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = function (n) { var el = form.querySelector('[name="' + n + '"]'); return el ? (el.options ? el.options[el.selectedIndex].text : el.value) : ''; };
      var text = ['메디코리아 제품 공급 문의 메모', '', '문의 제품: ' + v('pid'), '거래처 유형: ' + v('kind'),
        '거래처명: ' + v('company'), '회신 이메일: ' + v('email'), '', v('message'), '',
        '※ 시연용 사이트입니다. 이 메모는 내 컴퓨터에만 저장되고 회사로 전송되지 않습니다.'].join('\n');
      var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
      var link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = '메디코리아_문의메모.txt';
      link.click();
      var done = document.createElement('p');
      done.textContent = '문의 메모를 내려받았습니다. 시연용이라 회사로 전송되지 않습니다.';
      form.after(done);
    });
  }
})();
