const items = [
 ['자작 합판','합판/보드류','가구 몸통과 선반을 검토할 때','가구·선반','두께, 단면 노출, 표면 등급'],
 ['일반 합판','합판/보드류','마감재 아래 바탕면을 계획할 때','바탕면·재단','사용 환경, 접착 사양, 장수'],
 ['집성판','집성판/계단재','상판의 결 방향과 마감을 정할 때','상판·가구','수종, 집성 방식, 마감면'],
 ['구조용 각재','구조재/판재','골조 부재의 조건을 협의할 때','골조·틀','설계 규격, 등급, 길이'],
 ['마감용 각재','각재','몰딩이나 테두리 디테일을 정할 때','몰딩·테두리','단면 치수, 모서리 가공'],
 ['데크재','방부목/데크','옥외 바닥의 사용 환경을 검토할 때','외부 바닥','수종, 표면 가공, 배수 조건'],
 ['석고보드','석고보드','내장 벽체의 마감 바탕을 정할 때','벽체·천장','두께, 장수, 요구 성능'],
 ['방부목','방부목/데크','외부 구조물의 부재를 준비할 때','외부 시설','사용 환경, 단면, 길이'],
 ['계단재','집성판/계단재','계단 디딤판의 마감을 정할 때','계단·실내 마감','폭, 단수, 모서리 가공'],
 ['일반 각재','각재','현장 틀과 보조 부재를 준비할 때','틀·현장 시공','단면, 길이, 본수'],
 ['구조용 판재','구조재/판재','도면에 지정된 부재를 준비할 때','골조·바닥','설계 등급, 치수, 수량'],
 ['MDF','합판/보드류','도장할 실내 가구를 제작할 때','가구·실내','두께, 마감, 재단 수량']
];
const $=s=>document.querySelector(s);
const storageKey='material-brief-v2';
let draft={};
try { draft=JSON.parse(sessionStorage.getItem(storageKey)) || {}; } catch {}
const saved=new Set((Array.isArray(draft.ids)?draft.ids:[]).filter(i=>Number.isInteger(i)&&items[i]));
const specs=draft.specs || {};
function remember(){$('#review').hidden=true;$('#status').textContent='';try{sessionStorage.setItem(storageKey, JSON.stringify({ids:[...saved],specs,memo:$('textarea').value}));}catch{}}
$('textarea').value=draft.memo || '';
$('textarea').addEventListener('input',remember);
const form = $('form');
const customer = form.elements.customer;
const email = form.elements.email;
const accessKey = window.inquirySettings?.web3formsAccessKey?.trim() || '';
const connected = Boolean(accessKey);
let sending = false;
for (const field of [customer, email]) field.addEventListener('input', remember);
if (connected) {
 $('#deliveryNote').textContent='문안을 확인한 뒤 상담 문의 보내기를 누르면 입력한 내용이 회사 담당자에게 전달됩니다.';
}
let category='전체';
function node(tag,text){const el=document.createElement(tag);el.textContent=text;return el}
function button(label,action){const el=node('button',label);el.type='button';el.onclick=action;return el}
function compare(){
 $('#count').textContent=saved.size;
 const area=$('#comparison');area.replaceChildren();
 if(!saved.size)area.append(node('p','품목 미정 · 원하는 용도나 재단 질문부터 적으세요.'));
 for(const i of saved){const row=node('div','');row.className='row';row.append(node('strong',items[i][0]),node('span',items[i][3]+' · '+items[i][4]),button('제거',()=>toggle(i)));const label=node('label','요청 규격 · 수량');const field=node('input','');field.placeholder='예: 18 mm, 5장';field.value=specs[i]||'';field.oninput=()=>{specs[i]=field.value;remember()};label.append(field);row.append(label);area.append(row)}
}
function toggle(i){saved.has(i)?saved.delete(i):saved.add(i);remember();compare();render()}
function detail(i){
 const [name,type,desc,use,criteria]=items[i];const sheet=$('#sheet');sheet.replaceChildren(node('small',type+' · 시연용 품목'),node('h2',name),node('p',desc));
 for(const line of ['검토 용도　'+use,'상담 전에 확인할 항목　'+criteria,'공급 규격·재고·납기는 상담 시 확인합니다.']){const p=node('p',line);p.className='detail';sheet.append(p)}
 sheet.append(button('이 자재로 상담하기',()=>{
   if (!saved.has(i)) toggle(i);
   $('dialog').close();
   location.hash='brief';
   $('#brief').scrollIntoView();
   $('textarea').focus({preventScroll:true});
 }));$('dialog').showModal()
}
function render(){
 const query=$('#search').value.trim().toLowerCase();const cards=$('#cards');cards.replaceChildren();
 items.forEach((item,i)=>{const [name,type,desc]=item;if((category!=='전체'&&type!==category)||!item.join(' ').toLowerCase().replace(/\s/g,'').includes(query.replace(/\s/g,'').replace(/용$/, '') || query))return;
 const card=node('article','');card.style.setProperty('--tone',['#b3996a','#8d7559','#bd9266','#775842','#a67955','#695f4d'][i]);
 card.append(node('small',type),node('h3',name),node('p',desc),button('상세 보기',()=>detail(i)),button(saved.has(i)?'담기 취소':'비교에 담기',()=>toggle(i)));cards.append(card)});
 $('#results').textContent=cards.children.length?'시연용 품목 '+cards.children.length+'개':'검색 결과가 없습니다. 다른 검색어나 분류를 선택하세요.';
}
$('#filters').replaceChildren();
for(const type of ['전체','각재','합판/보드류','석고보드','방부목/데크','구조재/판재','집성판/계단재']){const el=button(type,()=>{category=type;for(const b of $('#filters').children)b.setAttribute('aria-pressed',String(b===el));render()});el.setAttribute('aria-pressed',String(type===category));$('#filters').append(el)}
$('#search').oninput=render;$('.close').onclick=()=>$('dialog').close();
$('form').onsubmit=e=>{e.preventDefault();const memo=e.target.elements.memo.value.trim();
 if(!saved.size&&!memo){$('#status').textContent='자재를 담거나 요청사항을 입력하세요.';return}
 const lines=['재단·자재 상담', '업체명 또는 성함: '+(customer.value.trim() || '미입력'), '회신 이메일: '+(email.value.trim() || '미입력'),...Array.from(saved,i=>items[i][0]+' | '+(specs[i]||'요청 규격 미입력')+' | 확인 항목: '+items[i][4]),'요청사항',memo];$('#summary').textContent=lines.join('\n');
 $('#review').hidden=false;
 $('#send').disabled=!connected || sending;
 $('#status').textContent='문안을 확인하고 복사하거나 저장하세요.';
};
$('#send').onclick=async()=>{
 if (!connected || sending) return;
 if (!customer.value.trim() || !email.value.trim()) {
   $('#status').textContent='보내려면 업체명 또는 성함과 회신 이메일을 입력해주세요.';
   (!customer.value.trim() ? customer : email).focus();
   return;
 }
 if (!form.reportValidity()) return;
 const message=$('#summary').textContent;
 sending=true;
 $('#send').disabled=true;
 $('#status').textContent='상담 문의를 전송하고 있습니다.';
 try {
   const response=await fetch('https://api.web3forms.com/submit',{
     method:'POST', headers:{Accept:'application/json','Content-Type':'application/json'},
     body:JSON.stringify({access_key:accessKey,subject:'동해우드 재단·자재 상담',name:customer.value.trim(),email:email.value.trim(),message})
   });
   if (!response.ok || !(await response.json()).success) throw new Error('submission failed');
   $('#status').textContent='상담 문의가 접수되었습니다.';
 } catch {
   $('#status').textContent='전송을 확인하지 못했습니다. 문안을 복사하거나 잠시 후 다시 시도해주세요.';
   $('#send').disabled=false;
 } finally {sending=false;}
};
$('#copy').onclick=async()=>{
 try {await navigator.clipboard.writeText($('#summary').textContent);$('#status').textContent='상담 내용을 복사했습니다.';}
 catch {const range=document.createRange();range.selectNodeContents($('#summary'));const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);$('#status').textContent='선택된 문안을 직접 복사하거나 상담서 저장을 누르세요.';}
};
$('#download').onclick=()=>{const url=URL.createObjectURL(new Blob(['\uFEFF'+$('#summary').textContent],{type:'text/plain;charset=utf-8'}));
 const link=document.createElement('a');link.href=url;link.download='자재상담서.txt';link.click();setTimeout(()=>URL.revokeObjectURL(url),2000);$('#status').textContent='상담서 다운로드를 요청했습니다.'};
render();compare();
