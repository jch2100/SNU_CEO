// 홈페이지 담당자: 회사 수신 메일로 발급받은 Web3Forms Access Key만 입력하세요.
// 설정을 확인하고 홈페이지에 반영하기 전까지 공개 사이트는 변경되지 않습니다.
window.inquirySettings = { web3formsAccessKey: '' };
