"""Fill the bundled templates without changing their formatting. No AI API."""
from pathlib import Path
import argparse
import json
import re
import os

ROOT=Path(__file__).resolve().parent
TOKEN=re.compile(r"\{\{\s*(\w+)\s*\}\}")

def paragraphs(doc):
    yield from doc.paragraphs
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:yield from cell.paragraphs

def fill(kind, source, destination):
    data=json.loads(source.read_text(encoding="utf-8-sig"))
    limits=json.loads((ROOT/"field-limits.json").read_text(encoding="utf-8"))
    if set(data)!=set(limits):raise ValueError("Input fields do not match template fields")
    for key,limit in limits.items():
        if not isinstance(data[key],str) or not data[key].strip():raise ValueError(f"Missing text: {key}")
        if len(data[key])>limit:raise ValueError(f"Content exceeds limit: {key}; summarize before generating")
        if "{{" in data[key] or "}}" in data[key]:raise ValueError("Template delimiters are not permitted in field values")
    destination=destination.resolve()
    output=(ROOT/"output").resolve()
    if not destination.is_relative_to(output):raise ValueError("Save inside this workspace's output directory")
    if destination.suffix.lower()!=f".{kind}":raise ValueError("Output extension does not match format")
    if destination.exists():raise FileExistsError("Existing output preserved; choose a new file name")
    seen=set()
    def replace(text):
        def sub(match):
            key=match.group(1);seen.add(key);return data[key]
        return TOKEN.sub(sub,text)
    if kind=="docx":
        from docx import Document
        doc=Document(ROOT/"templates/company-standard.docx")
        for para in paragraphs(doc):
            for run in para.runs:
                if "{{" in run.text:run.text=replace(run.text)
    else:
        from pptx import Presentation
        doc=Presentation(ROOT/"templates/company-standard.pptx")
        for slide in doc.slides:
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        for run in para.runs:
                            if "{{" in run.text:run.text=replace(run.text)
    if seen!=set(limits):raise ValueError("Template field coverage mismatch; inspect template before using helper")
    destination.parent.mkdir(parents=True,exist_ok=True)
    # Exclusive creation also prevents an accidental overwrite between validation and save.
    try:
        with destination.open("xb") as stream:doc.save(stream)
    except Exception:
        # Preserve any partial file for diagnosis; never remove another output.
        raise
    if kind=="docx":
        from docx import Document
        reopened=Document(destination)
        texts=[p.text for p in paragraphs(reopened)]
    else:
        from pptx import Presentation
        reopened=Presentation(destination)
        texts=[s.text for sl in reopened.slides for s in sl.shapes if s.has_text_frame]
    if any(TOKEN.search(t) for t in texts):raise ValueError("Unfilled fields in saved file")
    return destination

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--format",choices=["docx","pptx"],required=True)
    parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    print(fill(args.format,args.input,args.output))
