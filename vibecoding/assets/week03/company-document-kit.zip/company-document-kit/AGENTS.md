# Company document workspace

Read README.md, FORMAT.md and CONTENT.md before creating a file. Ask which output format the user wants if unclear. Use the chosen existing template; inspect it before changing layout. Work with local files only.

Read input source material and the user's intended message, propose content mapping, distinguish facts from interpretations and unknowns, and confirm important omissions. Never invent names, dates, causal explanations or source numbers.

Preserve template geometry, fonts and sizes. Never shrink fonts to hide overflow. If content exceeds limits, ask about summarizing or adding pages. The bundled helper is for the bundled templates only; inspect and adapt separately for a company file.

Use render_document.py after preparing validated fields. Save a new file under output, reopen it and check content and layout. Report the exact saved path and performed checks. Preserve originals and existing outputs. Do not publish, send, delete or install dependencies without explaining the change and following the user's authorization.
