# Company-specific research quality

## Company context and decision
Use business materials to identify products/services, target customers, operating geography, dependencies, differentiators and priorities. Attribute document facts and user statements. Unknown revenue, customer intent, market share or employee structure stays unknown.

No sentence memo is required. Co-create: which readers need to make which decision based on changes in what. Expand vague wishes with two or three useful possibilities and tradeoffs. 'Expand the perspective' does not authorize extra website modules.

Record agreed entities/topics, geography, date/forecast windows, source scope, exclusions, readers and useful-output criteria in PLAN.md. Choose short/long horizons only when useful; do not impose the instructor's domain or schedule.

## Actual evidence
Read original sources; search snippets do not prove an original-source read. Prefer local official sources for country-specific facts. Distinguish publication, event/effective, retrieval and forecast dates. Explain any older structural report used for outlook instead of fresh signals.

Define inclusive/exclusive boundaries. Example only: 14 completed KST dates end on the previous KST date and start 13 days earlier. Do not include an unfinished current day or impose this period universally.

For each insight retain:
- Observed fact, original URL/publisher and dates.
- AI interpretation and the company context making it relevant.
- Company-wide significance and optional role-level implications/actions.
- Limits, counter-evidence and what would change the judgment.

An advertised course is supply/recruitment evidence, not actual attendance or purchase demand. Search interest is not buyer intent. Missing metrics do not establish an increase. Relative indices from different providers cannot simply be added. Never label an unconnected provider connected.

## Briefing, not a headline dump
Prefer a few substantive insights over a fixed quota: what changed, why this company should care, affected work, next check/action and source basis. Mentioning the company name in a generic report is not personalization. Ask what conclusions/actions would change if the company were replaced by an unrelated business.

Retain pilot and source-to-claim links. Later distinguish new evidence, changed judgments and maintained outlooks, with first-written/last-reviewed dates when useful. 'No material new signal' requires actual checks, not a failed run.

## Privacy and review
Use private context to improve relevance, but do not copy client identities, inquiries, private analytics, contract details, internal priorities or strategy into wider sharing by default. Agree owner-only, invited employee or publicly safe outputs. Permission to analyze is not publication consent.

Have the user judge relevance before automating. If the result is generic, revisit selection/interpretation rather than adding charts or more news. Save accepted changes, unresolved items and approval scope.
