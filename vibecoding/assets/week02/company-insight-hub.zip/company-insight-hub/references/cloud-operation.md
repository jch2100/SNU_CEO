# Cloud operation and evidence

## Inspect before promising
Inspect actual cloud scheduler and Sites interfaces. Local desktop automations/heartbeats differ from hosted cloud tasks. Hosting a website does not move a local script, skill or Windows credential to the cloud.

This skill supplies instructions, not subscriptions, APIs, hosting rights or cloud writer access. Do not promise free-account compatibility. Never request passwords/tokens in chat. Use supported account connections; explain specific missing capabilities. No new payment, account creation, unrelated connection or access change without applicable authorization.

If scheduling requires a published Site, that path cannot satisfy a strictly site-free stage 2. Explain and obtain a decision: minimal owner-private operational foundation before employee UI, or an approved adjustment to dependent verification. Do not create a dummy Site silently or pretend stage 2 completed. Preserve the approved business stages and label technical subchecks honestly.

## Cloud-readable contract
Save a non-secret operational revision with:
- Business purpose, readers, criteria, source rules and date calculation.
- Actual tools/endpoints from supported interfaces, required identity/scope and how a fresh job obtains access.
- Output fields and retained result location; once DB exists, write/readback and screen mapping.
- Unique runs, idempotent retry behavior, partial failure rules and stopping condition.

A local skill path in a scheduled prompt is not cloud provisioning. Verify a fresh job can retrieve the revision without setup-chat context. A supported self-contained prompt can suffice when it contains the criteria and no secrets; otherwise use a hosted criteria tool/resource.

Keep write access narrower than visitor reads. Service-read access may neither represent an owner nor authorize writes. Verify source access and writer authorization separately. Never make records publicly writable, disable authentication or expose private material to unblock work. Obtain credentials only through supported connections/secret storage.

## Preserve real runs
Adapt to the actual schema. Retain unique ID, kind, start/end time, criteria revision, period/timezone, source URLs/publishers/dates, source-linked facts, AI analysis, company/role implications, next actions, collection status, failures, uncertainty and changes.

Keep private inputs out of distributable payloads. Retain past runs. Same ID/body retry should not duplicate; changed body must conflict or use a revision. Do not manufacture successful history to fill a UI. Fictional fixtures must be labeled and excluded from production.

## Trial and ongoing schedule
Resolve exact near-future trial time/timezone and consent. If time has passed, propose another. Inspect saved tasks after unknown outcomes instead of creating duplicates. Use actual returned IDs and supported idempotency keys; never invent update APIs.

Stage 2 requires actual cloud execution, fresh research, retained result, quality/date-window comparison and user acceptance. A manual write proves readiness at most.

Stage 3 adds actual scheduled write response, independent same-ID/body/time readback, matching page, history and access/content checks. An open-page refresh is not investigation. An author's temporary credentials working once do not prove future jobs can reacquire them.

Unseen run: registered, execution unobserved. Running: in progress. Failed/partial: identify components, preserve previous normal data and explain next check. Do not say 'no change' for tool failure or rerun indefinitely. Respect notification preferences.

After accepted trials activate only the agreed recurring schedule, avoiding old local/cloud duplicates. Completed one-off history can remain if non-repeating. Do not delete unrelated tasks. Record real management location and task IDs; unavailable pause/delete controls require explanation, not invented commands.

## QA honesty
Check originals/evidence navigation, responsive screen, permissions, private-content absence and immutable history. HTTP output is not proof of every browser interaction.

Fictional companies/mock schedulers/mock storage prove only simulated behavior or local prototype usability. They do not prove live cloud execution, learner subscription rights, security of real connections or paid/free availability. New live scheduling/publication needs scoped authorization. Do not turn installation/QA permission into blanket production access.
