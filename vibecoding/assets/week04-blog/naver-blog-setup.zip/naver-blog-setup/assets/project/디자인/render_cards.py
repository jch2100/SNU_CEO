import argparse
import base64
import html
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
from urllib.parse import quote


DESIGN = Path(__file__).resolve().parent
WIDTH = 1080
CARDS = {
    "00-thumbnail": ("thumbnail", 1080, ("title", "label", "subtitle", "brand")),
    "01-summary": ("summary", 1080, ("title", "subtitle", "label_1", "detail_1", "label_2", "detail_2")),
    "02-focus": ("focus", 1080, ("title", "focus", "unit", "detail", "note")),
    "03-checklist": ("checklist", 1080, ("title", "step_1", "step_2", "step_3", "note")),
}

LAYOUT_CHECK = """
<script>
window.addEventListener('load', async () => {
  await document.fonts.ready;
  if (Array.from(document.images).some(image => !image.complete || !image.naturalWidth)) {
    document.body.dataset.cardLayout = 'image-error';
    return;
  }
  const failed = Array.from(document.fonts).filter(font => font.status === 'error');
  if (failed.length) {
    document.body.dataset.cardLayout = 'font-error';
    return;
  }
  const textFields = document.querySelectorAll(
    '.headline, .label, .subtext, .account, .card-title, .card-body, .body-text, .big-number, .big-unit, .step-text'
  );
  for (const field of textFields) {
    const range = document.createRange();
    range.selectNodeContents(field);
    const rects = Array.from(range.getClientRects());
    if (rects.some(rect => rect.left < 1 || rect.top < 1 ||
        rect.right > document.body.clientWidth - 1 ||
        rect.bottom > document.body.clientHeight - 1) ||
        field.scrollWidth > field.clientWidth + 2) {
      document.body.dataset.cardLayout = 'overflow';
      return;
    }
  }
  document.body.dataset.cardLayout = 'ok';
});
</script>
"""


def find_browser(override):
    if override:
        candidates = [override]
    else:
        candidates = [
            shutil.which(name) for name in
            ("chrome", "google-chrome", "chromium", "msedge", "microsoft-edge")
        ]
        candidates += [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            str(Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            str(Path.home() / "Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
        ]
        for env_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            root = os.environ.get(env_name)
            if root:
                candidates += [
                    str(Path(root) / "Google/Chrome/Application/chrome.exe"),
                    str(Path(root) / "Microsoft/Edge/Application/msedge.exe"),
                ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    raise ValueError("Chrome 또는 Edge를 찾지 못했습니다. 브라우저 설치 위치를 --browser로 지정하세요.")


def read_card_text(metadata, section, fields):
    card = metadata.get(section)
    if not isinstance(card, dict):
        raise ValueError(f"카드.json에 {section} 항목이 필요합니다.")
    values = {}
    for field in fields:
        value = card.get(field)
        if not isinstance(value, str) or (field != "unit" and not value.strip()):
            raise ValueError(f"카드.json의 {section}.{field}에 문구를 적어주세요.")
        values[field] = value.strip()
    return values


def make_html(template, values, output_dir):
    style = (DESIGN / "theme.css").read_text(encoding="utf-8")
    font_file = DESIGN / "assets" / "PretendardVariable.woff2"
    relative_font = Path(os.path.relpath(font_file, output_dir)).as_posix()
    replacements = {
        name: html.escape(text).replace("\n", "<br>") for name, text in values.items()
    }
    replacements.update(
        theme=style,
        font_path=quote(relative_font, safe="/."),
        layout_check=LAYOUT_CHECK.strip(),
        page_title=html.escape(" ".join(values["title"].splitlines())),
    )
    if "focus" in values:
        replacements["focus_style"] = (
            "" if re.fullmatch(r"[\d,.%+\-]+", values["focus"]) else "word-focus"
        )

    def substitute(match):
        name = match.group(1)
        if name not in replacements:
            raise ValueError(f"{template.name}에 연결되지 않은 문구가 있습니다. {name}")
        return replacements[name]

    source = template.read_text(encoding="utf-8")
    return re.sub(r"\{\{([a-z_1-3]+)\}\}", substitute, source)


def render(browser, source, target, height, profile):
    command = [
        browser, "--headless", "--disable-gpu", "--disable-extensions", "--no-first-run",
        "--disable-background-networking", "--force-device-scale-factor=1",
        f"--user-data-dir={profile}", f"--window-size={WIDTH},{height}",
        "--virtual-time-budget=4000", "--timeout=10000", f"--screenshot={target}",
        "--dump-dom", source.as_uri(),
    ]
    result = subprocess.run(command, capture_output=True, timeout=30, check=False)
    dom = result.stdout.decode("utf-8", errors="replace")
    if 'data-card-layout="overflow"' in dom:
        raise ValueError(f"{source.stem} 글씨가 카드 영역을 벗어납니다. 문구를 줄이거나 줄바꿈하세요.")
    if 'data-card-layout="font-error"' in dom:
        raise ValueError(f"{source.stem}의 글꼴을 읽지 못했습니다. 디자인/assets 위치를 확인하세요.")
    if 'data-card-layout="image-error"' in dom:
        raise ValueError(f"{source.stem}의 사진을 브라우저에서 읽지 못했습니다.")
    if result.returncode or not target.is_file() or 'data-card-layout="ok"' not in dom:
        detail = result.stderr.decode("utf-8", errors="replace").strip().splitlines()[-2:]
        raise ValueError(f"{source.stem} 브라우저 출력 확인 실패. {' '.join(detail)}")
    with target.open("rb") as image:
        header = image.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"{target.name}에 PNG 데이터가 없습니다.")
    if struct.unpack(">II", header[16:24]) != (WIDTH, height):
        raise ValueError(f"{target.name} 크기가 {WIDTH}×{height}가 아닙니다.")


def read_capture(data, section, post, brand):
    values = read_card_text(data, section, ("title", "image", "image_alt", "caption"))
    asset_directory = (post / "이미지").resolve()
    asset = (post / values["image"]).resolve()
    if not asset_directory.is_relative_to(post) or not asset.is_relative_to(asset_directory):
        raise ValueError(f"{section} 사진을 글 폴더의 이미지 폴더에 넣어주세요.")
    payload = asset.read_bytes()
    if payload.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif payload.startswith(b"\xff\xd8\xff"):
        mime = "image/jpeg"
    else:
        raise ValueError(f"{section} 사진은 PNG 또는 JPEG여야 합니다.")
    encoded = base64.b64encode(payload).decode("ascii")
    return {
        "brand": brand,
        "title": values["title"],
        "image_alt": " ".join(values["image_alt"].split()),
        "caption": values["caption"],
        "image_data": f"data:{mime};base64,{encoded}",
    }


def create_cards(browser, post):
    results = (DESIGN.parent / "블로그_결과").resolve()
    if post.parent != results or not post.is_dir():
        raise ValueError("블로그_결과 바로 아래에 글 폴더를 만들고 해당 폴더를 지정하세요.")
    data = json.loads((post / "카드.json").read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("카드.json의 가장 바깥은 항목을 가진 객체여야 합니다.")
    brand = read_card_text(data, "thumbnail", ("brand",))["brand"]
    content = {}
    for name, (section, _, fields) in CARDS.items():
        card = data.get(section)
        if section != "thumbnail" and isinstance(card, dict) and "image" in card:
            content[name] = ("capture.html", read_capture(data, section, post, brand))
        else:
            content[name] = (f"{name}.html", read_card_text(data, section, fields))

    # The staging folder shares the post folder's depth so the final HTML keeps its relative font path.
    with tempfile.TemporaryDirectory(prefix=".cards-", dir=post.parent) as temp:
        stage = Path(temp)
        stage_html = stage / "html"
        stage_html.mkdir()
        for name, (_, height, _) in CARDS.items():
            source = stage_html / f"{name}.html"
            template_name, values = content[name]
            template = DESIGN / "templates" / template_name
            source.write_text(make_html(template, values, stage_html), encoding="utf-8")
            render(browser, source, stage / f"{name}.png", height, stage / "browser")

        html_dir = post / "html"
        html_dir.mkdir(exist_ok=True)
        for name in CARDS:
            os.replace(stage_html / f"{name}.html", html_dir / f"{name}.html")
            os.replace(stage / f"{name}.png", post / f"{name}.png")
            print(f"{name}.png")


def main():
    parser = argparse.ArgumentParser(description="네이버 블로그 썸네일과 본문 카드 PNG를 출력합니다.")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true", help="Chrome 또는 Edge 경로와 기본 디자인 파일을 확인합니다.")
    mode.add_argument("--post", type=Path, help="카드.json을 저장한 블로그_결과 안의 글 폴더")
    parser.add_argument("--browser", help="자동 검색되지 않는 Chrome 또는 Edge 실행 파일")
    args = parser.parse_args()
    try:
        browser = find_browser(args.browser)
        if args.check:
            required = [DESIGN / "theme.css", DESIGN / "assets/PretendardVariable.woff2"]
            required.extend(DESIGN / "templates" / f"{name}.html" for name in CARDS)
            required.append(DESIGN / "templates/capture.html")
            missing = [path.name for path in required if not path.is_file()]
            if missing:
                raise ValueError("디자인 파일이 없습니다. " + ", ".join(missing))
            print(f"기본 디자인과 브라우저 경로 확인: {browser}")
        else:
            create_cards(browser, args.post.resolve())
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()
