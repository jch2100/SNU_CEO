# 외부 디자인과 글꼴 출처

## instagram-card-news · Blueprint

- 출처: [junghwaYang/instagram-card-news](https://github.com/junghwaYang/instagram-card-news/tree/9959842c87037714e782bfd4e5f89661ffe64dae)
- 라이선스: 원본 [README 라이선스 항목](https://github.com/junghwaYang/instagram-card-news/blob/9959842c87037714e782bfd4e5f89661ffe64dae/README.md#라이선스)의 MIT 표기.
- 사용한 원본: `templates/blueprint/cover.html`, `content-split.html`, `content-bigdata.html`, `content-steps.html`.
- 적용한 변경: 사진이 없는 본문 카드 세 장에 Blueprint 레이아웃을 사용한다. 연한 종이색과 녹색으로 색을 조정했으며 현재 썸네일과 본문 카드는 모두 1080×1080이다.

## 제작 흐름과 시각 참고

- [Aside 공유 실습](https://share.aside.com/s/AWGyGERXCQeo0S0P)의 썸네일과 실제 화면 카드에서 종이색 바탕, 녹색 강조, 큰 제목, 화면과 캡션 구성을 참고했다. 템플릿은 이 프로젝트에서 작성했고 실제 실습 이미지나 문구는 패키지에 포함하지 않았다.
- [sphereai.work 네이버 블로그 시작 안내](https://sphereai.work/skills/naver-blog-start-here)의 공개 단계 설명에서 주제·본문·제목 카드·편집기 조립 순서를 참고했다.
- [modoo.today 공개 카탈로그](https://skills.modoo.today/en)의 `card-news-naver` 설명에서 한 장 한 메시지, 휴대폰에서 읽을 큰 한글, 카드 전후 본문과 이미지 설명을 참고했다.

MIT License

Upstream attribution: junghwaYang and contributors, instagram-card-news.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Pretendard Variable

[orioncactus/pretendard v1.3.9](https://github.com/orioncactus/pretendard/tree/v1.3.9)에서 배포한 WOFF2를 사용했다. [SIL Open Font License 1.1](assets/Pretendard-OFL.txt).
