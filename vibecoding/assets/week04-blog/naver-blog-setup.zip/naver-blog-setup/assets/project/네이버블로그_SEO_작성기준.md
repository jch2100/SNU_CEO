# 네이버 블로그 SEO 작성 기준

MIT 오픈소스 `ninestonelee/naver-blog-writer`의 질문형 구성, 핵심 답 먼저 쓰기, 출처 확인, 모바일 읽기 점검을 수업용 단일 Markdown 파일로 발췌·수정했다. [원본 SKILL.md](https://github.com/ninestonelee/naver-blog-writer/blob/775fa66e8fe5a5153cf255fb8946d3e20edc528f/SKILL.md) · [MIT 라이선스 원문](https://github.com/ninestonelee/naver-blog-writer/blob/775fa66e8fe5a5153cf255fb8946d3e20edc528f/LICENSE)

## 시작할 때

이 파일과 폴더에 저장된 브랜드 기준을 읽는다. 확인된 고객과 서비스, 공개 가능한 근거, 다음 행동과 실제 연결 주소, 브랜드 말투를 글에 활용한다. 주제와 관련된 사실이나 주소를 확인하지 못하면 근거가 있는 범위에서 원고를 쓰고, 부족한 항목을 검토 기록에 남긴다.

## 주제에서 글로

1. **검색 질문을 고른다.** 사용자가 쓰고 싶은 주제에서 고객이 네이버에 입력할 법한 질문을 찾는다. 검색 의도는 ‘알아보기’, ‘비교하기’, ‘실행하기’, ‘구매·예약 검토’ 중 가까운 것으로 정리한다. 검색 결과나 고객 문의를 확인했으면 출처와 확인일을 적는다. 검색량 자료가 없으면 검색어 후보로 표시한다.
2. **제목과 첫 문단에 답을 담는다.** 제목에 고객이 알아볼 표현을 자연스럽게 넣고 글에서 답하는 범위를 보여준다. 첫 문단에서 핵심 답을 준다. 읽는 사람이 사용한 표현을 의미 있게 반영하고 반복해서 채우지 않는다.
3. **질문에 맞는 구조를 고른다.** 선택 문제라면 비교 기준과 예외, 실행 문제라면 단계와 주의점, 경험담이라면 실제 장면과 배운 점을 쓴다. 모바일에서 훑어볼 수 있게 소제목과 짧은 문단을 사용한다. FAQ는 앞에서 답하지 않은 실제 질문이 남아 있을 때 추가한다.
4. **근거를 붙인다.** 공식 자료, 공개가 허용된 사례나 실제 사진에서 확인한 사실만 사용한다. 가격, 날짜, 인원, 효능·성과처럼 중요한 내용은 확인 뒤 쓴다. 근거 없는 숫자와 사례는 `확인 필요`로 돌리고 초안에는 넣지 않는다.
5. **다음 행동 하나를 안내한다.** 독자의 상황과 브랜드 목표에 맞게 글당 CTA 하나를 고른다. 안내할 혜택이나 연결 주소가 확인되지 않으면 `확인 필요`로 남긴다. 정보 탐색 단계의 글에서는 도움이 되는 판단 기준이나 검증된 관련 글을 다음 행동으로 둘 수 있다.
6. **카드와 원고를 맞춘다.** 썸네일 1장은 주제와 읽을 이유를 보여준다. 본문 카드 3장은 원고에서 훑어보기 어려운 설명을 골라 핵심 정리, 비교나 예시, 실행 순서나 체크리스트로 나눈다. 카드에 있는 핵심 답과 링크는 글에서도 읽거나 열 수 있게 한다.

## 결과물

- **글 설계** | 고객, 고객이 검색할 질문, 검색 의도, 고른 소재와 근거, 다음 행동과 주소.
- **원고** | 제목, 첫 문단, 소제목과 본문, 필요한 링크.
- **카드 문안** | 각 카드의 제목과 짧은 본문, 권장 이미지와 출처 또는 사진 확보 여부.
- **검토** | 카드가 들어갈 자리를 적고, 사실, 링크, 이미지 사용 권한 등 사람이 확인할 항목과 완성 상태를 표시한다.

제목과 첫 문단의 약속이 일치하는지, 사실과 가설이 섞이지 않았는지, CTA의 링크를 열 수 있는지, 휴대폰에서 본문과 카드가 읽히는지 점검한다. 이 기준은 검색 의도와 글 품질을 점검하는 작성 기준이다. 발행은 운영자가 확인한 뒤 네이버의 공식 기능에서 진행한다. [네이버 블로그 검색 노출 안내](https://help.naver.com/service/5593/contents/9564)

## 바로 써보는 요청

> 나 이번에 [주제]를 주제로 블로그 글을 쓸 거야.

## 원본 라이선스

MIT License

Copyright (c) 2026 ninestonelee

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
